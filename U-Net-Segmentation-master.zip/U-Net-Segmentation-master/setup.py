from setuptools import setup, find_packages

setup(name='Segmentation',
      version='0.1',
      description='U-Net Segmentation',
      url='',
      author='',
      author_email='',
      license='MIT',
      packages=['Segmentation'],
      install_requires=[
          'markdown',
      ],
      zip_safe=False)
